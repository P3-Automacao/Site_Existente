jQuery(function($){
	
	$(window).load(function() {
		
		$('#customizer .button').click(function(){
		
			$('#customizer').toggleClass('closed');
		
		});
	
	});
	
});